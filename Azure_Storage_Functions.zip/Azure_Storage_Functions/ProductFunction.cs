using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Azure.Data.Tables;
using Azure.Storage.Blobs;
using HttpMultipartParser;
using System.IO;
using System.Net;
using System.Text.Json;
using System;
using System.Threading.Tasks;
using Azure;
using System.Text.Json.Serialization;

public class ProductFunction
{
    private readonly TableClient _productTableClient;
    private readonly BlobServiceClient _blobServiceClient;
    private const string ContainerName = "abcblob";

    public ProductFunction()
    {
        string connectionString = "DefaultEndpointsProtocol=https;AccountName=st10028058;AccountKey=rSR7U+sKIaIi4NGX4lIAcleanfNhdqsl36mE6wW7ZZ+qPD4lsevyPDfyKEtQ5HOr9X86qjFX/liC+AStpIYKhQ==;EndpointSuffix=core.windows.net";

        // Initialize Table and Blob clients
        _productTableClient = new TableClient(connectionString, "Products");
        _blobServiceClient = new BlobServiceClient(connectionString);
    }

    [Function("AddProduct")]
    public async Task<HttpResponseData> AddProduct(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequestData req,
        FunctionContext executionContext)
    {
        var logger = executionContext.GetLogger("AddProduct");
        logger.LogInformation("Processing a request to add a new product.");

        // Parse the multipart form data
        MultipartFormDataParser formData;
        try
        {
            formData = await MultipartFormDataParser.ParseAsync(req.Body);
        }
        catch (Exception ex)
        {
            logger.LogError($"Error parsing multipart form data: {ex.Message}");
            var badRequestResponse = req.CreateResponse(HttpStatusCode.BadRequest);
            await badRequestResponse.WriteStringAsync("Invalid form data.");
            return badRequestResponse;
        }

        // Get the product JSON from the form data
        var productJson = formData.GetParameterValue("product");
        Product? product = JsonSerializer.Deserialize<Product>(productJson);

        if (product == null)
        {
            return req.CreateResponse(HttpStatusCode.BadRequest);
        }

        // Upload image to Blob Storage if provided
        if (formData.Files.Count > 0)
        {
            var imageFile = formData.Files.First();
            var imageUrl = await UploadImageToBlob(imageFile);
            product.ImageUrl = imageUrl;
        }

        // Set PartitionKey and RowKey for Table Storage
        product.PartitionKey = "ProductsPartition";
        product.RowKey = Guid.NewGuid().ToString();

        try
        {
            // Add product to Azure Table Storage
            await _productTableClient.AddEntityAsync(product);
        }
        catch (Exception ex)
        {
            logger.LogError($"Error adding product to Table Storage: {ex.Message}");
            var errorResponse = req.CreateResponse(HttpStatusCode.InternalServerError);
            await errorResponse.WriteStringAsync("Failed to add product to Table Storage.");
            return errorResponse;
        }

        // Return success response
        var response = req.CreateResponse(HttpStatusCode.Created);
        await response.WriteStringAsync("Product added successfully.");
        return response;
    }

    private async Task<string> UploadImageToBlob(FilePart file)
    {
        var containerClient = _blobServiceClient.GetBlobContainerClient(ContainerName);
        var blobClient = containerClient.GetBlobClient(file.FileName);

        // Upload the image to Blob Storage
        using (var stream = file.Data)
        {
            await blobClient.UploadAsync(stream, overwrite: true);
        }

        return blobClient.Uri.ToString();
    }
}

public class Product : ITableEntity
{
    public int Product_Id { get; set; }
    public string? Product_Name { get; set; }
    public string? Description { get; set; }
    public string? ImageUrl { get; set; }
    public double Product_Price { get; set; }
    public int Quantity { get; set; }

    public string? PartitionKey { get; set; }
    public string? RowKey { get; set; }
    [JsonIgnore]
    public ETag ETag { get; set; }
    public DateTimeOffset? Timestamp { get; set; }
}
