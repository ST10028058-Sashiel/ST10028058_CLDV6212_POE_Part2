using System.IO;
using System.Threading.Tasks;
using Azure.Storage.Files.Shares;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using System.Net;
using Microsoft.AspNetCore.WebUtilities;

public class FileUploadFunction
{
    private readonly ILogger<FileUploadFunction> _logger;
    private readonly IConfiguration _configuration;

    public FileUploadFunction(ILogger<FileUploadFunction> logger, IConfiguration configuration)
    {
        _logger = logger;
        _configuration = configuration;
    }

    [Function("UploadFile")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequestData req)
    {
        _logger.LogInformation("File upload function started.");

        // Read and parse form data from request body
        var boundary = HeaderUtilities.RemoveQuotes(MediaTypeHeaderValue.Parse(req.Headers.GetValues("Content-Type").First()).Boundary).Value;
        var reader = new MultipartReader(boundary, req.Body);
        MultipartSection section;
        IFormFile file = null;

        // Loop through each section of the form to find the file
        while ((section = await reader.ReadNextSectionAsync()) != null)
        {
            if (ContentDispositionHeaderValue.TryParse(section.ContentDisposition, out var contentDisposition))
            {
                // This is a file section
                if (contentDisposition.DispositionType.Equals("form-data") && contentDisposition.FileName.HasValue)
                {
                    var fileName = contentDisposition.FileName.Value;
                    file = new FormFile(section.Body, 0, section.Body.Length, contentDisposition.Name.Value, fileName);
                }
            }
        }

        if (file == null || file.Length == 0)
        {
            var badResponse = req.CreateResponse(HttpStatusCode.BadRequest);
            await badResponse.WriteStringAsync("Please upload a valid file.");
            return badResponse;
        }

        // Retrieve configuration settings
        string connectionString = _configuration["AzureWebJobsStorage"];
        string fileShareName = _configuration["FileShareName"];
        string directoryName = "uploads";

        // Connect to Azure File Share
        var serviceClient = new ShareServiceClient(connectionString);
        var shareClient = serviceClient.GetShareClient(fileShareName);
        var directoryClient = shareClient.GetDirectoryClient(directoryName);
        await directoryClient.CreateIfNotExistsAsync();

        var fileClient = directoryClient.GetFileClient(file.FileName);

        // Upload the file to Azure File Share
        using (var stream = file.OpenReadStream())
        {
            await fileClient.CreateAsync(stream.Length);
            await fileClient.UploadRangeAsync(new Azure.HttpRange(0, stream.Length), stream);
        }

        // Return success response
        var response = req.CreateResponse(HttpStatusCode.OK);
        await response.WriteStringAsync($"File '{file.FileName}' uploaded successfully.");
        return response;
    }
}
