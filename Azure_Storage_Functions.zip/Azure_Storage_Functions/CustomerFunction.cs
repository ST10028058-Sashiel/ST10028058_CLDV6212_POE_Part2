using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Azure.Data.Tables;
using Azure;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

public class CustomerFunction
{
    private readonly TableClient _customerTableClient;

    public CustomerFunction()
    {
        // Replace this connection string with the one you provided
        string connectionString = "DefaultEndpointsProtocol=https;AccountName=st10028058;AccountKey=rSR7U+sKIaIi4NGX4lIAcleanfNhdqsl36mE6wW7ZZ+qPD4lsevyPDfyKEtQ5HOr9X86qjFX/liC+AStpIYKhQ==;EndpointSuffix=core.windows.net";
        _customerTableClient = new TableClient(connectionString, "Customers");
    }

    [Function("AddCustomer")]
    public async Task<HttpResponseData> AddCustomer([HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequestData req, FunctionContext executionContext)
    {
        var logger = executionContext.GetLogger("AddCustomer");
        logger.LogInformation("Adding a new customer to Azure Table Storage.");

        // Read the request body
        var requestBody = await new StreamReader(req.Body).ReadToEndAsync();

        // Deserialize the JSON into a Customer object
        Customer? customer = JsonSerializer.Deserialize<Customer>(requestBody);
        if (customer == null)
        {
            var badRequestResponse = req.CreateResponse(HttpStatusCode.BadRequest);
            await badRequestResponse.WriteStringAsync("Invalid customer data.");
            return badRequestResponse;
        }

        // Generate PartitionKey and RowKey if they are not already set
        customer.PartitionKey = "CustomersPartition";
        customer.RowKey = Guid.NewGuid().ToString();

        try
        {
            // Add the new customer to the Azure Table
            await _customerTableClient.AddEntityAsync(customer);
        }
        catch (Exception ex)
        {
            logger.LogError($"Error adding customer to Table Storage: {ex.Message}");
            var errorResponse = req.CreateResponse(HttpStatusCode.InternalServerError);
            await errorResponse.WriteStringAsync("Error adding customer to Table Storage.");
            return errorResponse;
        }

        // Return success response
        var response = req.CreateResponse(HttpStatusCode.Created);
        await response.WriteStringAsync("Customer added successfully.");
        return response;
    }
}
public class Customer : ITableEntity
{
    [Key]
    public int Customer_Id { get; set; }
    public string? Customer_Name { get; set; }
    public string? email { get; set; }
    public string? password { get; set; }

    // ITableEntity implementation
    public string PartitionKey { get; set; }
    public string RowKey { get; set; }
    public ETag ETag { get; set; }
    public DateTimeOffset? Timestamp { get; set; }
}