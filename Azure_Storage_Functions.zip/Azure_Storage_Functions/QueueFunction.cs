using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using Azure.Data.Tables;
using Azure.Storage.Queues;
using Azure;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using System;
using System.Text.Json.Serialization;

public class OrderFunction
{
    private readonly TableClient _orderTableClient;
    private readonly QueueClient _queueClient;

    public OrderFunction()
    {
        // Replace this connection string with the one you provided
        string connectionString = "DefaultEndpointsProtocol=https;AccountName=st10028058;AccountKey=rSR7U+sKIaIi4NGX4lIAcleanfNhdqsl36mE6wW7ZZ+qPD4lsevyPDfyKEtQ5HOr9X86qjFX/liC+AStpIYKhQ==;EndpointSuffix=core.windows.net";

        // Initialize TableClient and QueueClient
        _orderTableClient = new TableClient(connectionString, "Orders");
        _queueClient = new QueueClient(connectionString, "productorders");
    }

    [Function("AddOrder")]
    public async Task<HttpResponseData> AddOrder([HttpTrigger(AuthorizationLevel.Function, "post", Route = null)] HttpRequestData req, FunctionContext executionContext)
    {
        var logger = executionContext.GetLogger("AddOrder");
        logger.LogInformation("Adding a new order to Azure Table Storage and sending to the Queue.");

        // Read the request body
        var requestBody = await new StreamReader(req.Body).ReadToEndAsync();

        // Deserialize the JSON into an Order object
        Order? order = JsonSerializer.Deserialize<Order>(requestBody);
        if (order == null)
        {
            var badRequestResponse = req.CreateResponse(HttpStatusCode.BadRequest);
            await badRequestResponse.WriteStringAsync("Invalid order data.");
            return badRequestResponse;
        }

        // Generate PartitionKey and RowKey if they are not already set
        order.PartitionKey = order.Customer_ID.ToString();
        order.RowKey = Guid.NewGuid().ToString();

        try
        {
            // Add the new order to Azure Table Storage
            await _orderTableClient.AddEntityAsync(order);

            // Prepare a message for the queue
            string queueMessage = $"New order created for Customer {order.CustomerName}, Product {order.ProductName}";

            // Send the message to Azure Queue Storage
            if (!_queueClient.Exists())
            {
                await _queueClient.CreateAsync();
            }
            await _queueClient.SendMessageAsync(queueMessage);
        }
        catch (Exception ex)
        {
            logger.LogError($"Error adding order to Table Storage or Queue: {ex.Message}");
            var errorResponse = req.CreateResponse(HttpStatusCode.InternalServerError);
            await errorResponse.WriteStringAsync("Error processing the order.");
            return errorResponse;
        }

        // Return success response
        var response = req.CreateResponse(HttpStatusCode.Created);
        await response.WriteStringAsync("Order added successfully and message sent to queue.");
        return response;
    }
}

public class Order : ITableEntity
{
    public int Order_Id { get; set; }
    public string? PartitionKey { get; set; }
    public string? RowKey { get; set; }

    [JsonIgnore]
    public ETag ETag { get; set; }
    public DateTimeOffset? Timestamp { get; set; }
    public int Customer_ID { get; set; }
    public int Product_ID { get; set; }
    public DateTime Order_Date { get; set; }
    public string? Order_Address { get; set; }
    public string? CustomerName { get; set; }
    public string? ProductName { get; set; }
}
